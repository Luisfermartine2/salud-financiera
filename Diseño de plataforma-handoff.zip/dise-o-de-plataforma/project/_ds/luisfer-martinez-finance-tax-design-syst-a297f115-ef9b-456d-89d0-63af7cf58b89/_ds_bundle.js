/* @ds-bundle: {"format":4,"namespace":"LuisferMartinezFinanceTaxDesignSystem_a297f1","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Checkbox","sourcePath":"components/core/Checkbox.jsx"},{"name":"Dialog","sourcePath":"components/core/Dialog.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Input","sourcePath":"components/core/Input.jsx"},{"name":"Select","sourcePath":"components/core/Select.jsx"},{"name":"Switch","sourcePath":"components/core/Switch.jsx"},{"name":"Tabs","sourcePath":"components/core/Tabs.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"Toast","sourcePath":"components/core/Toast.jsx"},{"name":"Tooltip","sourcePath":"components/core/Tooltip.jsx"},{"name":"AllocationRow","sourcePath":"components/finance/AllocationRow.jsx"},{"name":"DataTable","sourcePath":"components/finance/DataTable.jsx"},{"name":"PriceInput","sourcePath":"components/finance/PriceInput.jsx"},{"name":"StatCard","sourcePath":"components/finance/StatCard.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"4bcdef55c7ce","components/core/Button.jsx":"d1feef6c3a33","components/core/Card.jsx":"f51006db14b8","components/core/Checkbox.jsx":"2c2585fa0d3d","components/core/Dialog.jsx":"8451bb6b21c9","components/core/IconButton.jsx":"aaccaa7e6b86","components/core/Input.jsx":"12829f055a0f","components/core/Select.jsx":"2b62e09bef23","components/core/Switch.jsx":"da44833eebd2","components/core/Tabs.jsx":"2d98457accdd","components/core/Tag.jsx":"44739c78757d","components/core/Toast.jsx":"536a04478bcf","components/core/Tooltip.jsx":"75a887172bf5","components/finance/AllocationRow.jsx":"8c839ff317c7","components/finance/DataTable.jsx":"7d9164759708","components/finance/PriceInput.jsx":"f094f89d0eee","components/finance/StatCard.jsx":"377cf4bac85a"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.LuisferMartinezFinanceTaxDesignSystem_a297f1 = window.LuisferMartinezFinanceTaxDesignSystem_a297f1 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Badge.jsx
try { (() => {
function Badge({
  tone = 'neutral',
  children
}) {
  const tones = {
    neutral: {
      color: 'var(--text-secondary)',
      border: 'var(--border-strong)',
      bg: 'transparent'
    },
    accent: {
      color: 'var(--accent-strong)',
      border: 'var(--accent-strong)',
      bg: 'transparent'
    },
    gain: {
      color: 'var(--gain)',
      border: 'var(--gain)',
      bg: 'var(--gain-soft)'
    },
    loss: {
      color: 'var(--loss)',
      border: 'var(--loss)',
      bg: 'var(--loss-soft)'
    }
  }[tone];
  return React.createElement('span', {
    style: {
      display: 'inline-block',
      fontSize: 9.5,
      fontWeight: 700,
      textTransform: 'uppercase',
      letterSpacing: '.08em',
      color: tones.color,
      border: '1px solid ' + tones.border,
      background: tones.bg,
      borderRadius: 5,
      padding: '2px 8px'
    }
  }, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function Button({
  variant = 'primary',
  size = 'md',
  disabled,
  icon,
  children,
  onClick,
  type = 'button'
}) {
  const pad = {
    sm: '8px 14px',
    md: '11px 18px',
    lg: '13px 22px'
  }[size];
  const fs = {
    sm: '12.5px',
    md: '14px',
    lg: '15px'
  }[size];
  const base = {
    fontFamily: 'var(--font-sans)',
    fontWeight: 600,
    fontSize: fs,
    padding: pad,
    borderRadius: 'var(--r-md)',
    border: '1px solid transparent',
    cursor: disabled ? 'not-allowed' : 'pointer',
    display: 'inline-flex',
    alignItems: 'center',
    gap: '8px',
    transition: 'filter var(--dur-fast) var(--ease-standard), background var(--dur-fast) var(--ease-standard)',
    opacity: disabled ? .5 : 1
  };
  const styles = {
    primary: {
      background: 'var(--brand)',
      color: 'var(--text-on-brand)'
    },
    accent: {
      background: 'var(--accent)',
      color: 'var(--navy-950)'
    },
    secondary: {
      background: 'var(--surface-2)',
      color: 'var(--text-primary)',
      borderColor: 'var(--border)'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--text-primary)'
    },
    danger: {
      background: 'var(--loss)',
      color: '#fff'
    }
  };
  return React.createElement('button', {
    type,
    disabled,
    onClick,
    style: {
      ...base,
      ...styles[variant]
    },
    onMouseOver: e => {
      if (!disabled) e.currentTarget.style.filter = 'brightness(1.08)';
    },
    onMouseOut: e => {
      e.currentTarget.style.filter = 'none';
    }
  }, icon, children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function Card({
  hero,
  children,
  style
}) {
  return React.createElement('div', {
    style: {
      background: 'var(--surface)',
      border: '1px solid ' + (hero ? 'var(--accent)' : 'var(--border)'),
      borderRadius: 'var(--r-lg)',
      padding: '20px 22px',
      position: 'relative',
      overflow: 'hidden',
      ...style
    }
  }, hero && React.createElement('div', {
    style: {
      position: 'absolute',
      inset: '0 0 auto 0',
      height: 2,
      background: 'var(--accent)'
    }
  }), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Checkbox.jsx
try { (() => {
function Checkbox({
  label,
  checked,
  onChange
}) {
  return React.createElement('label', {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      fontFamily: 'var(--font-sans)',
      fontSize: 13,
      color: 'var(--text-primary)',
      cursor: 'pointer'
    }
  }, React.createElement('input', {
    type: 'checkbox',
    checked,
    onChange,
    style: {
      width: 16,
      height: 16,
      accentColor: 'var(--brand)'
    }
  }), label);
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/core/Dialog.jsx
try { (() => {
function Dialog({
  open,
  onClose,
  title,
  children
}) {
  if (!open) return null;
  return React.createElement('div', {
    style: {
      position: 'fixed',
      inset: 0,
      background: 'rgba(11,15,20,.5)',
      backdropFilter: 'blur(2px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 100
    },
    onClick: onClose
  }, React.createElement('div', {
    onClick: e => e.stopPropagation(),
    style: {
      background: 'var(--surface)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--r-lg)',
      boxShadow: 'var(--shadow-lg)',
      padding: 24,
      minWidth: 320,
      fontFamily: 'var(--font-sans)'
    }
  }, title && React.createElement('div', {
    style: {
      fontSize: 16,
      fontWeight: 700,
      marginBottom: 12,
      color: 'var(--text-primary)'
    }
  }, title), children));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function IconButton({
  children,
  onClick,
  active,
  label
}) {
  return React.createElement('button', {
    onClick,
    'aria-label': label,
    title: label,
    style: {
      width: 38,
      height: 38,
      background: active ? 'var(--surface-2)' : 'var(--surface)',
      border: '1px solid ' + (active ? 'var(--accent)' : 'var(--border)'),
      color: active ? 'var(--accent-strong)' : 'var(--text-secondary)',
      borderRadius: 'var(--r-md)',
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      transition: 'border-color var(--dur-fast),color var(--dur-fast)'
    }
  }, children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Input.jsx
try { (() => {
function Input({
  label,
  mono,
  placeholder,
  value,
  onChange,
  align = 'left'
}) {
  return React.createElement('label', {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      fontFamily: 'var(--font-sans)'
    }
  }, label && React.createElement('span', {
    style: {
      fontSize: 10,
      fontWeight: 600,
      letterSpacing: '.1em',
      textTransform: 'uppercase',
      color: 'var(--text-tertiary)'
    }
  }, label), React.createElement('input', {
    placeholder,
    value,
    onChange,
    style: {
      fontFamily: mono ? 'var(--font-mono)' : 'var(--font-sans)',
      fontSize: 13,
      padding: '9px 12px',
      borderRadius: 'var(--r-sm)',
      border: '1px solid var(--border)',
      background: 'var(--surface-2)',
      color: 'var(--text-primary)',
      textAlign: align,
      outline: 'none'
    }
  }));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Input.jsx", error: String((e && e.message) || e) }); }

// components/core/Select.jsx
try { (() => {
function Select({
  label,
  options = [],
  value,
  onChange
}) {
  return React.createElement('label', {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      fontFamily: 'var(--font-sans)'
    }
  }, label && React.createElement('span', {
    style: {
      fontSize: 10,
      fontWeight: 600,
      letterSpacing: '.1em',
      textTransform: 'uppercase',
      color: 'var(--text-tertiary)'
    }
  }, label), React.createElement('select', {
    value,
    onChange,
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 13,
      padding: '9px 12px',
      borderRadius: 'var(--r-sm)',
      border: '1px solid var(--border)',
      background: 'var(--surface-2)',
      color: 'var(--text-primary)'
    }
  }, options.map(o => React.createElement('option', {
    key: o.value || o,
    value: o.value || o
  }, o.label || o))));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Select.jsx", error: String((e && e.message) || e) }); }

// components/core/Switch.jsx
try { (() => {
function Switch({
  checked,
  onChange,
  label
}) {
  return React.createElement('label', {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 10,
      fontFamily: 'var(--font-sans)',
      fontSize: 13,
      color: 'var(--text-primary)',
      cursor: 'pointer'
    }
  }, React.createElement('span', {
    onClick: () => onChange && onChange(!checked),
    style: {
      width: 38,
      height: 22,
      borderRadius: 999,
      background: checked ? 'var(--brand)' : 'var(--border-strong)',
      position: 'relative',
      transition: 'background var(--dur-fast)'
    }
  }, React.createElement('span', {
    style: {
      position: 'absolute',
      top: 2,
      left: checked ? 18 : 2,
      width: 18,
      height: 18,
      borderRadius: 999,
      background: '#fff',
      transition: 'left var(--dur-fast) var(--ease-standard)',
      boxShadow: 'var(--shadow-sm)'
    }
  })), label);
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Switch.jsx", error: String((e && e.message) || e) }); }

// components/core/Tabs.jsx
try { (() => {
const {
  useState
} = React;
function Tabs({
  tabs = [],
  defaultIndex = 0
}) {
  const [i, setI] = useState(defaultIndex);
  return React.createElement('div', {
    style: {
      fontFamily: 'var(--font-sans)'
    }
  }, React.createElement('div', {
    style: {
      display: 'flex',
      gap: 4,
      borderBottom: '1px solid var(--border)',
      marginBottom: 16
    }
  }, tabs.map((t, idx) => React.createElement('button', {
    key: idx,
    onClick: () => setI(idx),
    style: {
      padding: '10px 4px',
      marginRight: 18,
      fontSize: 12.5,
      fontWeight: 600,
      background: 'none',
      border: 'none',
      borderBottom: '2px solid ' + (idx === i ? 'var(--brand)' : 'transparent'),
      color: idx === i ? 'var(--text-primary)' : 'var(--text-tertiary)',
      cursor: 'pointer'
    }
  }, t.label))), tabs[i] && tabs[i].content);
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function Tag({
  tone = 'neutral',
  children
}) {
  const tones = {
    neutral: {
      color: 'var(--text-secondary)',
      bg: 'var(--surface-2)',
      border: 'var(--border)'
    },
    accent: {
      color: '#a97e1c',
      bg: 'rgba(212,175,55,.14)',
      border: 'rgba(212,175,55,.4)'
    }
  }[tone];
  return React.createElement('span', {
    style: {
      display: 'inline-block',
      fontSize: 9.5,
      fontWeight: 600,
      letterSpacing: '.04em',
      color: tones.color,
      background: tones.bg,
      border: '1px solid ' + tones.border,
      borderRadius: 999,
      padding: '2px 9px',
      whiteSpace: 'nowrap'
    }
  }, children);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/core/Toast.jsx
try { (() => {
function Toast({
  tone = 'neutral',
  children
}) {
  const border = {
    neutral: 'var(--border-strong)',
    gain: 'var(--gain)',
    loss: 'var(--loss)'
  }[tone];
  return React.createElement('div', {
    style: {
      background: 'var(--surface)',
      border: '1px solid ' + border,
      borderRadius: 'var(--r-md)',
      boxShadow: 'var(--shadow-md)',
      padding: '12px 16px',
      fontFamily: 'var(--font-sans)',
      fontSize: 13,
      color: 'var(--text-primary)',
      display: 'inline-flex',
      alignItems: 'center',
      gap: 10
    }
  }, children);
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Toast.jsx", error: String((e && e.message) || e) }); }

// components/core/Tooltip.jsx
try { (() => {
const {
  useState
} = React;
function Tooltip({
  text,
  children
}) {
  const [show, setShow] = useState(false);
  return React.createElement('span', {
    style: {
      position: 'relative',
      display: 'inline-block'
    },
    onMouseEnter: () => setShow(true),
    onMouseLeave: () => setShow(false)
  }, children, show && React.createElement('span', {
    style: {
      position: 'absolute',
      bottom: 'calc(100% + 6px)',
      left: '50%',
      transform: 'translateX(-50%)',
      background: 'var(--navy-950)',
      color: '#fff',
      fontSize: 11,
      padding: '5px 9px',
      borderRadius: 6,
      whiteSpace: 'nowrap',
      zIndex: 10
    }
  }, text));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/finance/AllocationRow.jsx
try { (() => {
function AllocationRow({
  ticker,
  name,
  weightPct,
  valueLabel,
  tone = 'neutral'
}) {
  const fill = {
    neutral: 'var(--text-tertiary)',
    gain: 'var(--gain)',
    loss: 'var(--loss)'
  }[tone];
  return React.createElement('div', {
    style: {
      display: 'grid',
      gridTemplateColumns: 'minmax(120px,1.4fr) minmax(90px,3fr) auto auto',
      alignItems: 'center',
      gap: 16,
      padding: '14px 0',
      borderBottom: '1px solid var(--border)',
      fontFamily: 'var(--font-sans)'
    }
  }, React.createElement('div', {
    style: {
      fontSize: 13,
      fontWeight: 600,
      letterSpacing: '.04em',
      color: 'var(--text-primary)'
    }
  }, ticker, React.createElement('small', {
    style: {
      display: 'block',
      fontSize: 9.5,
      color: 'var(--text-tertiary)',
      textTransform: 'uppercase',
      fontWeight: 500,
      marginTop: 2
    }
  }, name)), React.createElement('div', {
    style: {
      height: 9,
      background: 'var(--surface-2)',
      borderRadius: 999,
      overflow: 'hidden'
    }
  }, React.createElement('div', {
    style: {
      height: '100%',
      width: weightPct + '%',
      background: fill,
      borderRadius: 999
    }
  })), React.createElement('div', {
    style: {
      fontSize: 12.5,
      color: 'var(--text-secondary)',
      minWidth: 100,
      textAlign: 'right',
      fontFamily: 'var(--font-mono)'
    }
  }, valueLabel), React.createElement('div', {
    style: {
      fontSize: 13.5,
      minWidth: 50,
      textAlign: 'right',
      fontWeight: 500,
      fontFamily: 'var(--font-mono)',
      color: 'var(--text-primary)'
    }
  }, weightPct + '%'));
}
Object.assign(__ds_scope, { AllocationRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/finance/AllocationRow.jsx", error: String((e && e.message) || e) }); }

// components/finance/DataTable.jsx
try { (() => {
function DataTable({
  columns = [],
  rows = []
}) {
  return React.createElement('div', {
    style: {
      background: 'var(--surface)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--r-lg)',
      overflow: 'hidden',
      fontFamily: 'var(--font-sans)'
    }
  }, React.createElement('div', {
    style: {
      overflowX: 'auto'
    }
  }, React.createElement('table', {
    style: {
      width: '100%',
      borderCollapse: 'collapse',
      minWidth: 600
    }
  }, React.createElement('thead', null, React.createElement('tr', null, columns.map((c, i) => React.createElement('th', {
    key: i,
    style: {
      fontSize: 9.5,
      fontWeight: 600,
      textTransform: 'uppercase',
      letterSpacing: '.12em',
      color: 'var(--text-tertiary)',
      textAlign: i === 0 ? 'left' : 'right',
      padding: '16px 18px 13px',
      borderBottom: '1px solid var(--border-strong)',
      whiteSpace: 'nowrap'
    }
  }, c)))), React.createElement('tbody', null, rows.map((r, ri) => React.createElement('tr', {
    key: ri
  }, r.map((cell, ci) => React.createElement('td', {
    key: ci,
    style: {
      padding: '14px 18px',
      textAlign: ci === 0 ? 'left' : 'right',
      borderBottom: '1px solid var(--border)',
      fontSize: 13.5,
      color: 'var(--text-primary)',
      whiteSpace: 'nowrap',
      fontFamily: ci === 0 ? 'var(--font-sans)' : 'var(--font-mono)'
    }
  }, cell))))))));
}
Object.assign(__ds_scope, { DataTable });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/finance/DataTable.jsx", error: String((e && e.message) || e) }); }

// components/finance/PriceInput.jsx
try { (() => {
function PriceInput({
  value,
  onChange,
  unreliable
}) {
  return React.createElement('input', {
    value,
    onChange,
    inputMode: 'numeric',
    title: unreliable ? 'Sin precio de mercado — valorado a costo' : undefined,
    style: {
      width: 104,
      background: 'var(--surface-2)',
      border: '1px solid ' + (unreliable ? 'var(--loss)' : 'var(--border-strong)'),
      borderRadius: 8,
      color: 'var(--text-primary)',
      fontFamily: 'var(--font-mono)',
      fontVariantNumeric: 'tabular-nums',
      fontSize: 13,
      textAlign: 'right',
      padding: '8px 10px',
      outline: 'none'
    }
  });
}
Object.assign(__ds_scope, { PriceInput });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/finance/PriceInput.jsx", error: String((e && e.message) || e) }); }

// components/finance/StatCard.jsx
try { (() => {
function StatCard({
  label,
  value,
  sub,
  tone = 'neutral',
  hero
}) {
  const toneColor = {
    neutral: 'var(--text-secondary)',
    gain: 'var(--gain)',
    loss: 'var(--loss)'
  }[tone];
  return React.createElement('div', {
    style: {
      background: 'var(--surface)',
      border: '1px solid ' + (hero ? 'var(--accent)' : 'var(--border)'),
      borderRadius: 'var(--r-lg)',
      padding: '20px 22px',
      position: 'relative',
      overflow: 'hidden'
    }
  }, hero && React.createElement('div', {
    style: {
      position: 'absolute',
      inset: '0 0 auto 0',
      height: 2,
      background: 'var(--accent)'
    }
  }), React.createElement('div', {
    style: {
      fontSize: 10,
      fontWeight: 600,
      textTransform: 'uppercase',
      letterSpacing: '.15em',
      color: 'var(--text-tertiary)',
      fontFamily: 'var(--font-sans)'
    }
  }, label), React.createElement('div', {
    style: {
      fontSize: hero ? 23 : 22,
      fontWeight: 300,
      marginTop: 15,
      color: 'var(--text-primary)',
      fontFamily: 'var(--font-sans)',
      whiteSpace: 'nowrap'
    }
  }, value), sub && React.createElement('div', {
    style: {
      fontSize: 12,
      marginTop: 11,
      color: toneColor,
      fontFamily: 'var(--font-mono)'
    }
  }, sub));
}
Object.assign(__ds_scope, { StatCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/finance/StatCard.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.AllocationRow = __ds_scope.AllocationRow;

__ds_ns.DataTable = __ds_scope.DataTable;

__ds_ns.PriceInput = __ds_scope.PriceInput;

__ds_ns.StatCard = __ds_scope.StatCard;

})();
